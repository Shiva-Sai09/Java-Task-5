1. What is inheritance in Java?
Inheritance is when one class (child/subclass) acquires the properties and methods of another class (parent/superclass).


2. Why use this keyword?
this refers to the current object of the class.
Differentiate between instance variables and local variables
Call another constructor in the same class (this())
Pass the current object as a parameter


3. Method Overriding vs Method Overloading (Theory Form)

Method Overriding happens when a subclass provides its own implementation of a method already defined in its parent class, using the same method name, parameter list, and return type. It’s used to achieve runtime polymorphism, meaning the method to be executed is decided at runtime based on the object type.

Method Overloading happens when two or more methods in the same class (or in a subclass) have the same name but different parameter lists (different number or types of parameters). It’s resolved at compile time and is a way to achieve compile-time polymorphism.


4. What is object instantiation?
It’s the process of creating an object from a class using the new keyword.


5. Single vs Multiple Inheritance (Theory Form)
Single Inheritance is when a class inherits from only one parent class. Java supports single inheritance directly, meaning a class can only extend one other class.
Multiple Inheritance is when a class inherits from more than one parent class. Java does not allow this with classes to avoid ambiguity problems such as the “diamond problem.” However, Java allows multiple inheritance through interfaces, where a class can implement multiple interfaces.


6. What is encapsulation?
Wrapping data (variables) and methods into a single unit (class) while restricting direct access to data.
Achieved by:
Making variables private
Providing public getter & setter methods

7. What is constructor overloading?
Having multiple constructors in the same class with different parameter lists.
Example:

class Car {
    Car() {}
    Car(String color) {}
}


8. Can we override static methods?
No 
Static methods belong to the class, not the object.
If you define the same static method in a subclass, it’s method hiding, not overriding.


9. What is runtime polymorphism?
Also called Dynamic Method Dispatch — method to call is determined at runtime based on the object's actual type.
Achieved through method overriding.


10. Difference Between Class and Object (Theory Form)
A class is a blueprint or template that defines the properties (fields) and behaviors (methods) that its objects will have. It does not consume memory until objects are created.
An object is an actual instance of a class, created in memory using the new keyword. Objects hold specific values for the properties defined in their class and can execute the class’s methods.